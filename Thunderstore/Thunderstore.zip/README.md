# CinematicCamera
Mod that enhances game's camera (configurable)

## Settings
I recommend to use `LethalConfig` for changing mod's settings  

# Changelog
### v1.1.0
* Config Overhaul
* Added health condition (configurable)

### v1.0.1 - v1.0.2
* Fix for game breaking bug

### v1.0.0
* Release